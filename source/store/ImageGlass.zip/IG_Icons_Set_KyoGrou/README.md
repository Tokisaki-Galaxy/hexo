## Icons Set for [ImageGlass](https://imageglass.org) file extensions

#### Contributor: [KyoGrou](https://github.com/KyoGrou)


#### Enquiries and discussion:
https://github.com/d2phap/ImageGlass/issues/217


## How to Install
- Support for ImageGlass 4.5 or later.
- You may want to back up the current icon set.
- Copy all icon files `(*.ico)` and paste to `ImageGlass\Ext-Icons` folder.