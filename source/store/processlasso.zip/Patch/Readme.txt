﻿1. Close the target program (if you installed Process Lasso, don't forget to
   stop core engine before exit). Also, check for any application icon in the
   notification area.

2. Start this tool, select the target product from the list and enter any
   licensee name you want to use.
   
3. Choose an activation method:

   - PERMANENT ACTIVATION: click on "Activate".
   
   - KEY FILE: click on "Make Key File" and select the output folder where the
     key file will be created, normally this folder should be the installation
     folder of the program.

4. OPTIONAL: use "Patch Hosts File" to block any activation check using the
   hosts file (or you can block Internet access to the program with a firewall).
